package com.teamandPlayer.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.teamandPlayer.Model.Team;
import com.teamandPlayer.services.TeamService;

@RestController
public class Team_Controller {
	
	@Autowired
	private TeamService teamSer;
	
	@CrossOrigin(origins="http://localhost:4200")
	@PostMapping("/createTeam")
	public Team saveTeam(@RequestBody Team team) throws Exception
	{
		Team teamObj=teamSer.fetchTeamByName(team.getTeamName());
		if(teamObj!=null)
		{
			throw new Exception("Team Name already exist");
		}
		else
		{
			teamSer.saveTeam(team);
		}
		return team;
	}
	
	
	@GetMapping("/getBudget/{name}")
	@CrossOrigin(origins="http://localhost:4200")
	public Double getMaximumBudgetByTeamName(@PathVariable ("name") String tempName) {
		return teamSer.getMaximumBudgetByTeamName(tempName);
	}
	
	@CrossOrigin(origins="http://localhost:4200")
	@GetMapping("/teamName")
	public List<Team> getAllteamName()
	{
		return teamSer.getallTeamName();
	}
	
	

}
