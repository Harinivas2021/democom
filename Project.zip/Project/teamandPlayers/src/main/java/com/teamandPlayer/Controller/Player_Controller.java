package com.teamandPlayer.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.teamandPlayer.Model.Player;
import com.teamandPlayer.Model.Team;
import com.teamandPlayer.services.PlayerService;
import com.teamandPlayer.services.TeamService;

@RestController
public class Player_Controller {
	
	@Autowired
	private PlayerService playerSer;
	
	@Autowired
	private TeamService teamService;
	
	@CrossOrigin(origins="http://localhost:4200")
	@PostMapping("/createPlayer")
	public Player createPlayer(@RequestBody Player player) throws Exception
	
	{ 
		Team teamObject=teamService.fetchTeamByName(player.getPlayerTeamName());
		List<Player> playerObj=playerSer.FetchPlayerByTeamName(player.getPlayerTeamName());
	
		if(playerObj.isEmpty() && teamObject!=null)
		{
			if(player.getPlayerBiddingBudget()<=teamObject.getTeamMaxBudget())
			{
			return playerSer.createPlayer(player);
			}
			
			else if(player.getPlayerBiddingBudget()>teamObject.getTeamMaxBudget())
			{
				throw new Exception("Player can't be tagged to this team as it's exceeds team's budget");
			}
		}
		else if(playerObj!=null && teamObject!=null)
		{
			int value=playerSer.sumOfPlayerBiddingBudget(player.getPlayerTeamName())+player.getPlayerBiddingBudget();
			System.out.println(value);
			if(value>teamObject.getTeamMaxBudget() )
			{
				throw new Exception("Player can't be tagged to this team as it's exceeds team's budget");
			}
			else
			{
				return playerSer.createPlayer(player);
			}
		}
		else if(player.getPlayerTeamName().equals("NA"))
		{
			return playerSer.createPlayer(player);
		}
		else if(teamObject==null)
		{
			throw new Exception("Team does not exist");
		}
		
		return player;
	}
	//Question3
	@CrossOrigin(origins="http://localhost:4200")
	@GetMapping("players/{teamName}")
	public List<Player> fetchPlayers(@PathVariable String teamName)
	{
		return playerSer.FetchPlayerByTeamName(teamName);
	}
	@CrossOrigin(origins="http://localhost:4200")
	@GetMapping("playerDetails/{playerName}")
	public List<Player> fetchPlayer(@PathVariable String playerName) throws Exception
	{
		if(playerSer.playerDetails(playerName).isEmpty())
		{
			throw new Exception("playerNot Exixt");
			
		}
		else {
			return playerSer.playerDetails(playerName);
			
		}
	}
	
	
	
}
