package com.teamandPlayer.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.teamandPlayer.Model.Team;
import com.teamandPlayer.Repository.TeamRepository;

@Service
public class TeamService {
	
	@Autowired
	private TeamRepository teamRepo;
	
	public Team saveTeam(Team team)
	{
		return teamRepo.save(team);
	}
	
	public Team fetchTeamByName(String tempName)
	{
		return (Team) teamRepo.findByTeamName(tempName);
	}
	
	public Double getMaximumBudgetByTeamName(String teamName) {
		return teamRepo.getMaximumBudgetByTeamName(teamName);
	}
	public List<Team> getallTeamName()
	{
		return teamRepo.findAll();
	}

	
}

