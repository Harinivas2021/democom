package com.teamandPlayer.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TeamandPlayersApplicationTests {

	@Test
	void contextLoads() {
	}

}
